THE GRAVITY 60-DAY GUIDED IMPROVEMENT PLAN LIBRARY

START HERE
1. Open START_HERE_Gravity_60-Day_Guided_Improvement_Library.pdf.
2. Select one plan using the restaurant's most important verified constraint.
3. Assign one accountable manager and record the baseline before coaching begins.
4. Complete each day's action in order. Use the added time for teaching, practice, observation, and correction—not delay.
5. On Day 60, standardize, extend the controlled test, redesign it, or stop the change based on evidence.

WHICH EDITION SHOULD I USE?
Use the 30-Day Accelerated edition for established managers, reliable operating data, and teams capable of daily structured follow-through.
Use this 60-Day Guided edition for beginning managers, newer or smaller teams, limited systems experience, or operations needing more repetition and coaching.

QUALITY PROMISE
The 60-day edition is not a lower standard. It preserves the same improvement areas, measures, operating requirements, protections, and intended outcomes as the 30-day edition. Only pacing and implementation support differ.

PACKAGE CONTENTS
- One complete editable Word master
- One complete 64-page PDF master
- One Start Here guide
- Twelve individual guided-plan PDFs
- One expansion roadmap

IMPLEMENTATION RULE
Run one plan at a time unless management capacity can protect measurement, ownership, training, coaching, and follow-through for every active plan. Do not run the 30-day and 60-day versions of the same plan simultaneously.


GRAVITY IMPROVEMENT IMPLEMENTATION KIT
This 60-Day Guided package includes the elite 24-page companion kit plus separate quick-start, plan-selection, manager-launch, employee-communication, measurement, completed-example, printable-form, glossary, FAQ, and next-step PDFs. Begin with the complete Implementation Kit before launching the selected plan.
