THE GRAVITY 30-DAY RESTAURANT IMPROVEMENT PLAN LIBRARY
ELITE EMAIL MEMBER EDITION

START HERE
1. Open START_HERE_Gravity_30-Day_Improvement_Library.pdf.
2. Select one plan using the restaurant's most important verified constraint.
3. Assign one accountable manager and record the baseline before coaching begins.
4. Complete each day's action in order and preserve the stated safety, quality, hospitality, fairness, and workload boundaries.
5. On Day 30, standardize, extend the controlled test, redesign it, or stop the change based on evidence.

BEST FIT
This accelerated edition is designed for established managers, teams with reliable operating data, and operations capable of disciplined daily follow-through. Beginning managers or teams needing additional instruction, repetition, and coaching should use the 60-Day Guided edition instead.

PACKAGE CONTENTS
- One complete editable Word master
- One complete 39-page PDF master
- One Start Here guide
- Twelve individual improvement-plan PDFs
- One expansion roadmap

IMPLEMENTATION RULE
Run one plan at a time unless management capacity can protect measurement, ownership, training, coaching, and follow-through for every active plan. Do not run the 30-day and 60-day versions of the same plan simultaneously.


GRAVITY IMPROVEMENT IMPLEMENTATION KIT
This 30-Day Accelerated package includes the elite 24-page companion kit plus separate quick-start, plan-selection, manager-launch, employee-communication, measurement, completed-example, printable-form, glossary, FAQ, and next-step PDFs. Begin with the complete Implementation Kit before launching the selected plan.
